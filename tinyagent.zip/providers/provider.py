import abc
from .providers import Client

class Provider(abc):
    @abc.abstractmethod
    def list_models() -> list[str]:
        pass

    @abc.abstractmethod
    def make_client(model_name) -> Client:
        pass